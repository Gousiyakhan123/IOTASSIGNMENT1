from django.apps import AppConfig


class Helloworld1Config(AppConfig):
    name = 'helloworld1'
