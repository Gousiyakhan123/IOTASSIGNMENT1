from django.shortcuts import render

# Create your views here.

from django.shortcuts import render

# Create your views here.

def helloworld(request): #server takes a request
    return render(request,'helloworld.html',{}) #and returns something back
