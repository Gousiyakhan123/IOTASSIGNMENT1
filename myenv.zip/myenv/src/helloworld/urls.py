from __future__ import unicode_literals

from django.db import models

# Create your models here.

from django.conf.urls import url
from . import views
import django.contrib.auth.views

urlpatterns = [
    url(r'^hello$', views.helloworld, name='helloworld'),
]

